# 🧩 Juego Adivinanza de Películas

🚀 Vamos a practicar metodología de proyecto utilizando:

- GitHub Projects
- Historias de Usuario
- Ramas `dev` y `main` y ramas auxiliares para las historias de usuario

